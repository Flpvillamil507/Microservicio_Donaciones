require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');



const donationsRoutes = require('./routes/donations');

const app = express();

app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

app.use('/api/donations', donationsRoutes);

// Conexión MongoDB
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB conectado'))
  .catch(err => console.error(err));

// Puerto
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log('Servidor backend corriendo en puerto${PORT}');
});