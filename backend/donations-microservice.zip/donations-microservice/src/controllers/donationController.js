const Donation = require('../models/Donation');

exports.createDonation = async (req, res) => {
  try {
    const donorName  = req.body.donorName  || req.body.nombre;
    const amount     = req.body.amount     || req.body.monto;
    const message    = req.body.message    || req.body.mensaje;
    // si decides no pedir email, elimínalo de la verificación
    if (!donorName || !amount) {
      return res.status(400).json({ error: 'Faltan campos obligatorios.' });
    }
    const donation = new Donation({ donorName, amount, message });
    await donation.save();
    res.status(201).json(donation);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.listDonations = async (req, res) => {
  try {
    const donations = await Donation.find().sort({ createdAt: -1 });
    res.json(donations);
  } catch (error) {
    res.status(500).json({ error: "Error al recuperar donaciones."});
}
};