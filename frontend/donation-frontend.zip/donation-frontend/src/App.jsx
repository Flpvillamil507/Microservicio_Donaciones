import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { DonationProvider } from "./context/DonationContext";
import DonationsPage from "./pages/DonationsPage";
import NewDonationPage from "./pages/NewDonationPage";

const router = createBrowserRouter([
  { path: "/", element: <DonationsPage /> },
  { path: "/nueva", element: <NewDonationPage /> },
]);

export default function App() {
  return (
    <DonationProvider>
      <RouterProvider router={router} />
    </DonationProvider>
  );
}
