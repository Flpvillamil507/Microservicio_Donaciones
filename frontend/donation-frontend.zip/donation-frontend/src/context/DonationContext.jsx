import { createContext, useReducer, useEffect } from "react";
import { getDonations } from "../api/api";

export const DonationContext = createContext();

function reducer(state, action) {
  switch (action.type) {
    case "LOAD":  return { ...state, list: action.payload, loading: false };
    case "ADD":   return { ...state, list: [action.payload, ...state.list] };
    case "ERR":   return { ...state, error: action.payload, loading: false };
    default:      return state;
  }
}

export function DonationProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, {
    list: [], loading: true, error: null,
  });

  useEffect(() => {
    getDonations()
      .then(r => dispatch({ type: "LOAD", payload: r.data }))
      .catch(e => dispatch({ type: "ERR", payload: e.message }));
  }, []);

  return (
    <DonationContext.Provider value={{ state, dispatch }}>
      {children}
    </DonationContext.Provider>
  );
}
