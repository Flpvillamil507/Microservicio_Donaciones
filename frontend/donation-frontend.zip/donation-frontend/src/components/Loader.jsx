// src/components/Loader.jsx
export default function Loader() {
  return (
    <div style={styles.spinner} aria-label="Cargando">
      Cargando…
    </div>
  );
}

const styles = {
  spinner: {
    padding: "1rem",
    textAlign: "center",
    fontWeight: "bold",
  },
};
