// src/components/DonationForm.jsx
import { useState, useContext } from "react";
import { createDonation } from "../api/api";
import { DonationContext } from "../context/DonationContext";

export default function DonationForm() {
  const { dispatch } = useContext(DonationContext);

  // estado local del formulario
  const [form, setForm] = useState({ donor: "", amount: "", message: "" });
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  // validación simple
  const amountNumber = Number(form.amount);
  const disabled =
    sending ||
    !form.donor.trim() ||
    !form.amount ||
    isNaN(amountNumber) ||
    amountNumber <= 0;

  // handler de envío
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (disabled) return;

    setSending(true);
    setError("");

    try {
      // payload con amount numérico
      const payload = {
        nombre: form.donor.trim(),
        monto : amountNumber,
        mensaje : form.message.trim() || undefined,
      };

      const { data } = await createDonation(payload);
      // actualiza el contexto global
      dispatch({ type: "ADD", payload: data });
      // limpia el formulario
      setForm({ donor: "", amount: "", message: "" });
    } catch (err) {
      setError(err.response?.data?.msg || err.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={styles.form} aria-live="polite">
      <h2 style={styles.h2}>Nueva Donación</h2>

      <label style={styles.label}>
        Nombre del donante
        <input
          style={styles.input}
          value={form.donor}
          onChange={(e) => setForm({ ...form, donor: e.target.value })}
          placeholder="Tu nombre"
          required
        />
      </label>

      <label style={styles.label}>
        Monto (USD)
        <input
          style={styles.input}
          type="number"
          min="1"
          step="0.01"
          value={form.amount}
          onChange={(e) => setForm({ ...form, amount: e.target.value })}
          placeholder="10.00"
          required
        />
      </label>

      <label style={styles.label}>
        Mensaje (opcional)
        <textarea
          style={{ ...styles.input, height: 80 }}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          placeholder="¡Gracias por ayudar a los peluditos!"
        />
      </label>

      {error && (
        <p role="alert" style={styles.error}>
          ⛔ {error}
        </p>
      )}

      <button type="submit" disabled={disabled} style={styles.button}>
        {sending ? "Enviando…" : "Donar"}
      </button>
    </form>
  );
}

/* ─────────────────────────  estilos en línea  ───────────────────────── */
const styles = {
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
    maxWidth: 460,
  },
  h2: {
    margin: "0 0 0.5rem",
  },
  label: {
    display: "flex",
    flexDirection: "column",
    fontWeight: 600,
    gap: "0.25rem",
  },
  input: {
    padding: "0.5rem",
    borderRadius: 6,
    border: "1px solid #ccc",
    fontSize: 16,
  },
  button: {
    padding: "0.75rem",
    borderRadius: 6,
    border: "none",
    background: "#1976d2",
    color: "#fff",
    fontWeight: 600,
    cursor: "pointer",
    opacity: 1,
  },
  error: {
    color: "crimson",
    fontWeight: 600,
  },
};
