// ✅ Muestra nombre, monto y mensaje
import styles from "./DonationCard.module.css";

export default function DonationCard({ d }) {
  const { donorName, amount, message } = d;

  return (
    /*  Fitts: toda la tarjeta es un botón (fácil de click/tap)  */
    <article
      className={styles.card}
      role="listitem"
      tabIndex={0}                       /* accesible con teclado */
      aria-label={`Donación de ${donorName } por $${ amount}`}
    >
      {/* Sistema-mundo real: encabezado claro, moneda local */}
      <header className={styles.header}>
        <span className={styles.donor}>{donorName}</span>
        <span className={styles.amount}>${amount}</span>
      </header>

      {/* Reconocer, no recordar: mensaje visible sin desplegar nada */}
      {message && <p className={styles.msg}>“{message}”</p>}
    </article>
  );
}
