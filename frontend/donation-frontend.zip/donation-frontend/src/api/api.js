import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
});

api.interceptors.response.use(
  r => r,
  err => {
    // Exponer errores en consola y propagar
    console.error(err.response?.data || err.message);
    return Promise.reject(err);
  }
);

export const getDonations = () => api.get("/donations");
export const createDonation = data => api.post("/donations", data);
