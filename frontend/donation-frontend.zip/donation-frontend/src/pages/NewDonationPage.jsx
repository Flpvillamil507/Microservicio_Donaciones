// src/pages/NewDonationPage.jsx
import { Link } from "react-router-dom";
import DonationForm from "../components/DonationForm";

export default function NewDonationPage() {
  return (
    <div style={pageStyle}>
      <h1>Nueva donacion</h1>

      <DonationForm />

      {/* Enlace para volver a la lista */}
      <p>
        <Link to="/">← Volver al listado</Link>
      </p>
    </div>
  );
}

const pageStyle = {
  maxWidth: "600px",
  margin: "0 auto",
  padding: "1rem",
};
