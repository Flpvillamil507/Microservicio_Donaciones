import { useContext } from "react";
import { DonationContext } from "../context/DonationContext";
import DonationCard from "../components/DonationCard";
import Loader from "../components/Loader";
import { Link } from "react-router-dom";
import styles from "./DonationsPage.module.css";
import paw from "../assets/paw.svg"; 

export default function DonationsPage() {
  const { state } = useContext(DonationContext);
  
  if (state.loading) return <Loader />;
  if (state.error)
    return <p role="alert" className={styles.error}>⛔ {state.error}</p>;
  
  return (
    <main className={styles.main}>
      {/* Encabezado: Coincidencia con el mundo real (logo + título claro) */}
      <header className={styles.header}>
        <img src={paw} alt="" className={styles.logo} aria-hidden="true" />
        <h1 className={styles.title}>Donaciones</h1>
        {/* Control y libertad / Fitts: botón grande, visible */}
        <Link to="/nueva" className={styles.addBtn}>
          + Nueva donación
        </Link>
      </header>

      {/* role=list para accesibilidad; Grid = estética minimalista + proximidad */}
      <section role="list" className={styles.grid}>
        {state.list.length === 0 ? (
          <p>No hay donaciones todavía 🙂</p>
        ) : (
          state.list.map((d) => (
            <DonationCard key={d._id} d={d} />
          ))
        )}
      </section>
    </main>
  );
}
